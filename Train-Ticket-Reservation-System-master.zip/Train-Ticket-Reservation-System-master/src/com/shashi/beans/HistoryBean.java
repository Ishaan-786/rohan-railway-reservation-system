package com.shashi.beans;

public class HistoryBean extends BookingDetails {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String transId;

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

}
